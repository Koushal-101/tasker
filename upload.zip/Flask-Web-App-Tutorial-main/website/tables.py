from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models.py import User, Note  # Import models and Base class

# Set up the engine and session
engine = create_engine("sqlite:///F:\python project\Flask-Web-App-Tutorial-main\Flask-Web-App-Tutorial-main\website\models.py")  # Adjust for your database type
Session = sessionmaker(bind=engine)
session = Session()

# Print table schema
print(User.__table__)