import pandas as pd
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models import User  # Replace with actual model and path

# Connect to the database
engine = create_engine("sqlite:///path_to_your_database.db")  # Update with actual database path
Session = sessionmaker(bind=engine)
session = Session()

# Query all data from the User table
users = session.query(User).all()

# Convert query results to a list of dictionaries
data = [{"id": user.id, "username": user.username, "password": user.password} for user in users]  # Adjust fields as necessary

# Create a DataFrame from the data
df = pd.DataFrame(data)

# Export DataFrame to an Excel file
df.to_excel("user_data.xlsx", index=False)
print("Data exported to user_data.xlsx")
