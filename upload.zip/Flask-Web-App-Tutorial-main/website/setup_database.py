from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models import User  

# Set up the database connection
engine = create_engine("sqlite:///path_to_your_database.db")  # Update with your actual database path and type
Session = sessionmaker(bind=engine)
session = Session()

# Query all data from the User (or credentials) table
users = session.query(User).all()

# Display each user's information
for user in users:
    print(f"User ID: {user.id}, Username: {user.username}, Password: {user.password}")  # Adjust fields as necessary
